import type { Translation } from "domain/types/Translation";

const fromDto = (some): Translation => {
  return {};
};
