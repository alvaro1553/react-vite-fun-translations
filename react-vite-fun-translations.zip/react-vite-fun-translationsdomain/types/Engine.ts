export type Engine = "yoda" | "pirate";
